For documentation regarding installation and operation of the Search Core 
software, point your favorite browser to the ./doc/index.html file.
